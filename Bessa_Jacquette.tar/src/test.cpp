#include "test.hpp"

test::test()
{
    //ctor
}

test::~test()
{
    //dtor
}
