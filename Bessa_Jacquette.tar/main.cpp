#include "Utilisateur.hpp"

int main()
{
    srand(time(0));
    Utilisateur::start();
    return 0;
}