var searchData=
[
  ['initnombre',['initNombre',['../classJeu__2048.html#af0a4ab15a24b87ca17848402353f0691',1,'Jeu_2048::initNombre()'],['../classJeu__2048__destroy.html#ab037257bf0c0af96a55451328d1772c4',1,'Jeu_2048_destroy::initNombre()'],['../classJeu__2048__double.html#aece2506ea63a7b8777de1211dd55ca7b',1,'Jeu_2048_double::initNombre()'],['../classJeu__2048__neg.html#abfe688a240d8b178cb9c7ce5130f023e',1,'Jeu_2048_neg::initNombre()']]],
  ['isfull',['isFull',['../classPlateau.html#a582d89742e77838aacbfba4ebbafef62',1,'Plateau']]]
];
