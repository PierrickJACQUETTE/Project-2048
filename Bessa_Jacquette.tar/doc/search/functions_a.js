var searchData=
[
  ['setacces',['setAcces',['../classCase.html#a5315b4118feb8a7b712703ddd0ec240a',1,'Case']]],
  ['setcase',['setCase',['../classPlateau.html#a83edb33891546b2c548c46f3e2c30bc9',1,'Plateau']]],
  ['setnombre',['setNombre',['../classCase.html#a017b1f216fbe2db8a28255d05cd41668',1,'Case']]],
  ['setplateau',['setPlateau',['../classJeu.html#ad0affab21946394d1296a5202b3c4890',1,'Jeu']]],
  ['setscore',['setScore',['../classJeu__2048.html#a1b4c357f1a39464bacbf789b4d71552b',1,'Jeu_2048']]],
  ['settypecase',['setTypeCase',['../classCase.html#ac8c66b59835e1e793791ae2185bd136a',1,'Case']]],
  ['setx',['setX',['../classCase.html#a8451e9cd70ff26dfc863df5e0e2ee91a',1,'Case']]],
  ['sety',['setY',['../classCase.html#a3378228d7d927c7016469f21567a77e4',1,'Case']]],
  ['simulerpartie',['simulerPartie',['../classJeu.html#a04cac85bd57338334c7aeccbe8ce49e8',1,'Jeu']]],
  ['start',['start',['../classUtilisateur.html#acbe6f6fa846a78b4fdefcfc282a6761c',1,'Utilisateur']]]
];
