var searchData=
[
  ['getacces',['getAcces',['../classCase.html#af1c9a94825c209ca28d511d56ab87f16',1,'Case']]],
  ['getcase',['getCase',['../classPlateau.html#a2b9aedc9495da439b4e1af40bfb62a22',1,'Plateau']]],
  ['getnbx',['getNbX',['../classPlateau.html#a94d176885d4c1003b6ebe64b164e8c21',1,'Plateau']]],
  ['getnby',['getNbY',['../classPlateau.html#aa79d0a19c7d1a1a87f9b82dd62d073a1',1,'Plateau']]],
  ['getnombre',['getNombre',['../classCase.html#ab289021f505c377cf25cbbfd3c0739eb',1,'Case']]],
  ['getplateau',['getPlateau',['../classJeu.html#ab3768cef0b062538f02e56591f23edec',1,'Jeu']]],
  ['getpuissance',['getPuissance',['../classJeu__2048.html#a560e733640a5803ea2140041c6a1d1bc',1,'Jeu_2048']]],
  ['getscore',['getScore',['../classJeu__2048.html#ad62b852ba17d0d1af6e2a7dfe2aa30f3',1,'Jeu_2048']]],
  ['gettaille',['getTaille',['../classPlateau.html#a297d9ffecc1cfe6fd4539403da36717c',1,'Plateau']]],
  ['gettypecase',['getTypeCase',['../classCase.html#a29ff21a91a58b9e4b1a454ecb4eb263a',1,'Case']]],
  ['getx',['getX',['../classCase.html#ab5580b919199dd2ec379672d3390bbff',1,'Case']]],
  ['gety',['getY',['../classCase.html#a824f612c5a660a1d55ac06931747c46d',1,'Case']]]
];
